/**********************************************************************
 * DVT_Helper (nRF5340)  —  board bring-up & self-test firmware
 * ====================================================================
 * Shell-driven diagnostic tool for the HW Designs nRF5340 BLE dev board
 * (Raytac MDBT53-1M + RP2040 CMSIS-DAP probe, Rev B, fab 2026-07-04).
 * Flash it, open the RP2040 probe's CDC serial port at 115200 (or an RTT
 * viewer), and type `dvt` for the command list. Every command is tagged
 * with the matching test ID from the board's DVT plan (e.g. GPIO-01,
 * IMEAS-04) so results map straight back to the tracker.
 *
 * Build (NCS v2.9+ / v3.x, sysbuild):
 *   west build -b nrf5340dk/nrf5340/cpuapp --sysbuild
 * The board is pin-compatible with the nRF5340-DK for uart0, i2c1 and
 * the MX25R64 QSPI flash; the ONE required deviation is the LFXO load
 * capacitance (internal 6 pF, set in prj.conf — the DK uses external
 * caps). See DVT_Firmware_Guide.docx for flashing over CMSIS-DAP
 * (west flash --runner pyocd / probe-rs; the nRF Connect VS Code
 * Flash/Debug buttons will NOT see this probe).
 *
 * BLE note: `dvt ble adv` needs the network-core image (ipc_radio,
 * built automatically by sysbuild). If the net core is blank the
 * command reports it and every wired test still runs — flash the net
 * core when you reach the RF section (guide §4).
 *
 * Copyright (c) 2026 HW Designs LLC — https://docs.hwdesigns.us
 * Published as an open example. Add your preferred license (e.g. MIT)
 * in the repository before distributing.
 *********************************************************************/

#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/shell/shell.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/drivers/adc.h>
#include <zephyr/drivers/flash.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/drivers/hwinfo.h>
#include <zephyr/pm/device.h>
#include <zephyr/sys/poweroff.h>
#include <zephyr/sys/reboot.h>
#include <hal/nrf_gpio.h>
#include <hal/nrf_clock.h>
#include <string.h>
#include <stdlib.h>

#if defined(CONFIG_BT)
#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/hci.h>
#include <zephyr/bluetooth/hci_vs.h>
#endif
#if defined(CONFIG_USB_DEVICE_STACK)
#include <zephyr/usb/usb_device.h>
#endif

#define FW_NAME "DVT-Helper-nRF5340"
#define FW_VER  "1.0"
#define BOARD_REV "Rev B (fab 2026-07-04)"

/* ------------- verified pin map, fab netlist 2026-07-04 -------------
 * Absolute pin number = port*32 + pin.  Labels are header.position.
 * UART0 (P0.20 TX / P0.22 RX) and I2C1 (P1.02 SDA / P1.03 SCL) are on
 * the headers too but are exercised by their own tests; `gpio walk all`
 * includes them (kills the UART console — use RTT, reset when done). */
struct hdr_pin { uint8_t abs; const char *label; const char *gpio; };

static const struct hdr_pin HDR_SAFE[] = {
	/* H1 (bottom edge, +5V end = pin 1) */
	{ 29, "H1.3",  "P0.29" }, {  7, "H1.4",  "P0.07/AIN3" },
	{ 25, "H1.5",  "P0.25/AIN4" }, { 26, "H1.6",  "P0.26/AIN5" },
	{ 27, "H1.7",  "P0.27/AIN6" }, { 10, "H1.9",  "P0.10" },
	{  9, "H1.10", "P0.09" }, {  8, "H1.11", "P0.08" },
	{ 33, "H1.13", "P1.01" },
	/* H2 (top edge, 3V3 end = pin 1) */
	{ 11, "H2.3",  "P0.11" }, { 12, "H2.4",  "P0.12" },
	{  5, "H2.5",  "P0.05/AIN1" }, {  6, "H2.6",  "P0.06/AIN2" },
	{  4, "H2.7",  "P0.04/AIN0" }, { 32, "H2.9",  "P1.00" },
	{ 47, "H2.10", "P1.15" }, { 46, "H2.11", "P1.14" },
	{ 44, "H2.12", "P1.12" }, { 31, "H2.14", "P0.31" },
	{ 28, "H2.15", "P0.28/AIN7" }, { 43, "H2.16", "P1.11" },
	{ 30, "H2.17", "P0.30" }, { 42, "H2.18", "P1.10" },
};
static const struct hdr_pin HDR_BUS[] = {   /* only in `gpio walk all` */
	{ 22, "H1.14", "P0.22 (UART RX)" }, { 20, "H1.15", "P0.20 (UART TX)" },
	{ 35, "H1.17", "P1.03 (SCL)" },     { 34, "H1.18", "P1.02 (SDA)" },
};
#define N_SAFE ARRAY_SIZE(HDR_SAFE)
#define N_BUS  ARRAY_SIZE(HDR_BUS)

/* Physically adjacent signal-signal pairs (indices into HDR_SAFE).
 * GND/3V3/bus pins between runs break adjacency, so pairs only span
 * contiguous signal runs on each header. */
static const uint8_t ADJ[][2] = {
	{0,1},{1,2},{2,3},{3,4},          /* H1.3-4-5-6-7            */
	{5,6},{6,7},                      /* H1.9-10-11              */
	{9,10},                           /* H2.3-4                  */
	{11,12},{12,13},                  /* H2.5-6-7                */
	{14,15},{15,16},{16,17},          /* H2.9-10-11-12           */
	{18,19},{19,20},{20,21},{21,22},  /* H2.14-15-16-17-18       */
};
#define N_ADJ ARRAY_SIZE(ADJ)

static const struct device *i2c_dev  = DEVICE_DT_GET(DT_NODELABEL(i2c1));
static const struct device *adc_dev  = DEVICE_DT_GET(DT_NODELABEL(adc));
static const struct device *qspi_dev = DEVICE_DT_GET(DT_NODELABEL(mx25r64));
static const struct device *uart0_dev = DEVICE_DT_GET(DT_NODELABEL(uart0));

/* --------------------------- utilities --------------------------- */
static void print_devid(const struct shell *sh)
{
	uint8_t id[8] = {0};
	ssize_t n = hwinfo_get_device_id(id, sizeof(id));
	shell_fprintf(sh, SHELL_NORMAL, "Device ID (board S/N): ");
	for (ssize_t i = 0; i < n; i++) {
		shell_fprintf(sh, SHELL_NORMAL, "%02X", id[i]);
	}
	shell_print(sh, "");
}

static const char *reset_reason(void)
{
	uint32_t cause = 0;
	hwinfo_get_reset_cause(&cause);
	hwinfo_clear_reset_cause();
	if (cause & RESET_PIN)      return "reset pin (SW4 / probe)";
	if (cause & RESET_SOFTWARE) return "software";
	if (cause & RESET_WATCHDOG) return "WATCHDOG";
	if (cause & RESET_DEBUG)    return "debugger";
	if (cause & RESET_LOW_POWER_WAKE) return "System OFF wake";
	if (cause & RESET_POR)      return "power-on";
	if (cause & RESET_BROWNOUT) return "BROWNOUT";
	return "unknown/none";
}

/* ------------------------ dvt info  (NRF-03) ---------------------- */
static int cmd_info(const struct shell *sh, size_t argc, char **argv)
{
	shell_print(sh, "%s v%s  |  %s", FW_NAME, FW_VER, BOARD_REV);
	shell_print(sh, "Base board: nrf5340dk/nrf5340/cpuapp + LFXO 6 pF overlay");
	print_devid(sh);
	shell_print(sh, "Reset reason: %s", reset_reason());
	shell_print(sh, "Uptime: %lld ms", k_uptime_get());
	shell_print(sh, "LFCLK: %s", nrf_clock_lf_actv_src_get(NRF_CLOCK) ==
		    NRF_CLOCK_LFCLK_XTAL ? "XTAL (X2, 6 pF internal caps)" :
		    "NOT XTAL — check X2 / CONFIG_SOC_LFXO_CAP_INT_6PF");
	return 0;
}

/* ------------------- dvt clk / clk cal (NRF-04/05) ---------------- */
static int cmd_clk(const struct shell *sh, size_t argc, char **argv)
{
	bool xtal = nrf_clock_lf_actv_src_get(NRF_CLOCK) == NRF_CLOCK_LFCLK_XTAL;
	shell_print(sh, "LFCLK source: %s  (NRF-04 expects XTAL)",
		    xtal ? "XTAL" : "RC/SYNTH");
	if (argc > 1 && strcmp(argv[1], "cal") == 0) {
		/* NRF-05: measure LFXO vs HFXO. DWT cycle counter runs from
		 * the CPU clock (HFXO-derived once the radio/HF is requested;
		 * HFXO tol ±10 ppm on the module) and k_uptime runs from the
		 * RTC (LFXO). Ratio over 8 s gives the LFXO error in ppm. */
		shell_print(sh, "Measuring LFXO vs CPU clock over 8 s — hands off...");
		CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
		DWT->CYCCNT = 0;
		DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
		int64_t t0 = k_uptime_get();
		uint32_t c0 = DWT->CYCCNT;
		k_sleep(K_MSEC(8000));
		uint32_t c1 = DWT->CYCCNT;
		int64_t t1 = k_uptime_get();
		double cyc = (double)(uint32_t)(c1 - c0);
		double ms  = (double)(t1 - t0);
		double f_meas = cyc / (ms / 1000.0);      /* CPU Hz if RTC ideal */
		double nom = (f_meas > 96.0e6) ? 128.0e6 : 64.0e6;
		/* If the RTC (LFXO) runs fast, measured interval is short and
		 * f_meas reads high — sign convention: +ppm = LFXO fast. */
		double ppm = (f_meas / nom - 1.0) * 1e6;
		shell_print(sh, "CPU %.3f MHz nominal %.0f MHz -> LFXO error %+0.1f ppm",
			    f_meas / 1e6, nom / 1e6, ppm);
		shell_print(sh, "NRF-05 limit: |ppm| <= 150 (record). Large error ->");
		shell_print(sh, "suspect LFXO load caps (must be internal 6 pF for X2).");
	}
	return 0;
}

/* ------------------- dvt gpio ...  (GPIO-01/02/03) ---------------- */
static void pin_default(uint8_t abs) { nrf_gpio_cfg_default(abs); }

static int cmd_gpio_walk(const struct shell *sh, size_t argc, char **argv)
{
	bool all = (argc > 1 && strcmp(argv[1], "all") == 0);
	shell_print(sh, "GPIO-01 walking output: each pin drives HIGH ~1.5 s,");
	shell_print(sh, "everything else driven LOW. DMM the announced pin (~3.3 V");
	shell_print(sh, "on 3V3_NRF rail) and spot-check neighbours (~0 V).");
	if (all) {
		shell_print(sh, ">>> 'all' mode includes UART/I2C pins — UART console");
		shell_print(sh, ">>> will die at H1.15; watch on RTT, reset when done.");
	}
	for (int i = 0; i < N_SAFE; i++) nrf_gpio_cfg_output(HDR_SAFE[i].abs);
	for (int i = 0; i < N_SAFE; i++) nrf_gpio_pin_clear(HDR_SAFE[i].abs);
	int total = all ? N_SAFE + N_BUS : N_SAFE;
	for (int i = 0; i < total; i++) {
		const struct hdr_pin *p = (i < N_SAFE) ? &HDR_SAFE[i]
						       : &HDR_BUS[i - N_SAFE];
		if (i >= N_SAFE) nrf_gpio_cfg_output(p->abs);
		nrf_gpio_pin_set(p->abs);
		shell_print(sh, "[%2d/%2d] HIGH on %-6s %s", i + 1, total,
			    p->label, p->gpio);
		k_sleep(K_MSEC(1500));
		nrf_gpio_pin_clear(p->abs);
	}
	for (int i = 0; i < N_SAFE; i++) pin_default(HDR_SAFE[i].abs);
	if (all) for (int i = 0; i < N_BUS; i++) pin_default(HDR_BUS[i].abs);
	shell_print(sh, "Walk done. %s", all ?
		    "Reset the board (SW4) to restore the UART console." :
		    "UART/I2C pins are covered by their own tests (or `gpio walk all`).");
	return 0;
}

static int cmd_gpio_in(const struct shell *sh, size_t argc, char **argv)
{
	shell_print(sh, "GPIO-02: all header GPIOs INPUT + PULL-UP. Expect all 1.");
	shell_print(sh, "Jumper each pin to GND -> reads 0. 20 samples, 1 s apart. ");
	for (int i = 0; i < N_SAFE; i++)
		nrf_gpio_cfg_input(HDR_SAFE[i].abs, NRF_GPIO_PIN_PULLUP);
	for (int s = 0; s < 20; s++) {
		char line[3 * N_SAFE + 8] = {0};
		int pos = 0;
		for (int i = 0; i < N_SAFE; i++)
			pos += snprintf(line + pos, sizeof(line) - pos, "%d ",
					(int)nrf_gpio_pin_read(HDR_SAFE[i].abs));
		shell_print(sh, "[%2d] %s", s, line);
		k_sleep(K_MSEC(1000));
	}
	shell_print(sh, "Pin order:");
	for (int i = 0; i < N_SAFE; i++)
		shell_print(sh, "  %2d: %-6s %s", i, HDR_SAFE[i].label, HDR_SAFE[i].gpio);
	for (int i = 0; i < N_SAFE; i++) pin_default(HDR_SAFE[i].abs);
	return 0;
}

static int cmd_gpio_pattern(const struct shell *sh, size_t argc, char **argv)
{
	shell_print(sh, "GPIO-03 adjacent-bridge test (automatic, no instruments).");
	int fails = 0;
	for (int k = 0; k < N_ADJ; k++) {
		const struct hdr_pin *a = &HDR_SAFE[ADJ[k][0]];
		const struct hdr_pin *b = &HDR_SAFE[ADJ[k][1]];
		bool ok = true;
		for (int dir = 0; dir < 2; dir++) {
			const struct hdr_pin *drv = dir ? b : a;
			const struct hdr_pin *sen = dir ? a : b;
			nrf_gpio_cfg_output(drv->abs);
			nrf_gpio_pin_clear(drv->abs);           /* drive LOW  */
			nrf_gpio_cfg_input(sen->abs, NRF_GPIO_PIN_PULLUP);
			k_busy_wait(300);
			if (nrf_gpio_pin_read(sen->abs) == 0) ok = false; /* bridged */
			pin_default(drv->abs); pin_default(sen->abs);
		}
		shell_print(sh, "  %-6s <-> %-6s : %s", a->label, b->label,
			    ok ? "PASS" : "FAIL (bridge?)");
		if (!ok) fails++;
	}
	shell_print(sh, "GPIO-03 result: %s (%d pair(s) failed of %d)",
		    fails ? "FAIL" : "PASS", fails, (int)N_ADJ);
	shell_print(sh, "Bridges to GND/3V3 planes show up in walk/in modes instead.");
	return 0;
}

/* ---------------------- dvt adc dump (GPIO-04) -------------------- */
static int cmd_adc(const struct shell *sh, size_t argc, char **argv)
{
	if (!device_is_ready(adc_dev)) {
		shell_error(sh, "ADC not ready");
		return -ENODEV;
	}
	/* AIN0..7 = P0.04 P0.05 P0.06 P0.07 P0.25 P0.26 P0.27 P0.28 */
	static const char *ain[8] = { "AIN0 P0.04 H2.7", "AIN1 P0.05 H2.5",
		"AIN2 P0.06 H2.6", "AIN3 P0.07 H1.4", "AIN4 P0.25 H1.5",
		"AIN5 P0.26 H1.6", "AIN6 P0.27 H1.7", "AIN7 P0.28 H2.15" };
	shell_print(sh, "GPIO-04: 10 rounds of AIN0..AIN7 in mV (0.6 V ref, 1/6 gain,");
	shell_print(sh, "12-bit). Feed the plan setpoints through ~10 k and compare to DMM.");
	for (int ch = 0; ch < 8; ch++) {
		struct adc_channel_cfg cfg = {
			.gain = ADC_GAIN_1_6,
			.reference = ADC_REF_INTERNAL,
			.acquisition_time = ADC_ACQ_TIME(ADC_ACQ_TIME_MICROSECONDS, 10),
			.channel_id = ch,
#if defined(CONFIG_ADC_CONFIGURABLE_INPUTS)
			.input_positive = SAADC_CH_PSELP_PSELP_AnalogInput0 + ch,
#endif
		};
		adc_channel_setup(adc_dev, &cfg);
	}
	for (int round = 0; round < 10; round++) {
		char line[128]; int pos = 0;
		for (int ch = 0; ch < 8; ch++) {
			int16_t raw = 0;
			struct adc_sequence seq = {
				.channels = BIT(ch), .buffer = &raw,
				.buffer_size = sizeof(raw), .resolution = 12,
			};
			int err = adc_read(adc_dev, &seq);
			int32_t mv = raw;
			adc_raw_to_millivolts(adc_ref_internal(adc_dev),
					      ADC_GAIN_1_6, 12, &mv);
			pos += snprintf(line + pos, sizeof(line) - pos, "%5d ",
					err ? -1 : mv);
		}
		shell_print(sh, "[%d] %s", round, line);
		k_sleep(K_MSEC(500));
	}
	for (int ch = 0; ch < 8; ch++) shell_print(sh, "  ch%d = %s", ch, ain[ch]);
	return 0;
}

/* ------------------ dvt i2c ...  (I2C-02/03/04) ------------------- */
static int i2c_speed(const struct shell *sh, bool fast)
{
	uint32_t cfg = I2C_MODE_CONTROLLER |
		       I2C_SPEED_SET(fast ? I2C_SPEED_FAST : I2C_SPEED_STANDARD);
	int err = i2c_configure(i2c_dev, cfg);
	shell_print(sh, "i2c1 @ %s kHz %s", fast ? "400" : "100",
		    err ? "CONFIG FAILED" : "");
	return err;
}

static int cmd_i2c_scan(const struct shell *sh, size_t argc, char **argv)
{
	if (!device_is_ready(i2c_dev)) { shell_error(sh, "i2c1 not ready"); return -ENODEV; }
	bool fast = (argc > 1 && strcmp(argv[1], "fast") == 0);
	i2c_speed(sh, fast);
	shell_print(sh, "%s scan (SDA P1.02 / SCL P1.03, pull-ups R40/R41 4.7 k",
		    fast ? "I2C-04" : "I2C-02");
	shell_print(sh, "to 3V3_NRF, Qwiic CN1 powered from 3V3_OTHER):");
	int found = 0;
	for (uint8_t a = 0x08; a < 0x78; a++) {
		uint8_t b;
		if (i2c_read(i2c_dev, &b, 1, a) == 0) {
			shell_print(sh, "  found 0x%02X%s", a,
				    a == 0x44 ? "  (SHT4x)" : "");
			found++;
		}
	}
	shell_print(sh, "%d device(s).", found);
	return 0;
}

static uint8_t sht_crc(const uint8_t *d)
{
	uint8_t crc = 0xFF;
	for (int i = 0; i < 2; i++) {
		crc ^= d[i];
		for (int b = 0; b < 8; b++)
			crc = (crc & 0x80) ? (crc << 1) ^ 0x31 : crc << 1;
	}
	return crc;
}

static int cmd_i2c_sht4x(const struct shell *sh, size_t argc, char **argv)
{
	bool fast = (argc > 1 && strcmp(argv[1], "fast") == 0);
	i2c_speed(sh, fast);
	uint8_t cmd = 0xFD, rx[6];
	int err = i2c_write(i2c_dev, &cmd, 1, 0x44);
	k_sleep(K_MSEC(12));
	err |= i2c_read(i2c_dev, rx, 6, 0x44);
	if (err) { shell_error(sh, "I2C-03/04 FAIL: no SHT4x response (%d)", err); return err; }
	bool crc_ok = sht_crc(rx) == rx[2] && sht_crc(rx + 3) == rx[5];
	double t  = -45.0 + 175.0 * ((rx[0] << 8 | rx[1]) / 65535.0);
	double rh = -6.0  + 125.0 * ((rx[3] << 8 | rx[4]) / 65535.0);
	shell_print(sh, "SHT4x @%s kHz: T = %.2f C, RH = %.1f %%, CRC %s",
		    fast ? "400" : "100", t, rh, crc_ok ? "OK" : "FAIL");
	shell_print(sh, "(I2C-03 @100 kHz, I2C-04 @400 kHz — plausible T/RH + CRC OK = pass)");
	return crc_ok ? 0 : -EIO;
}

/* ------------- dvt qspi id|test|dpd  (NRF-06/07, IMEAS-06) -------- */
#define QSPI_TEST_OFF 0x7FF000   /* last 4 K sector of the 8 MB MX25R64 */

static int cmd_qspi_id(const struct shell *sh, size_t argc, char **argv)
{
	if (!device_is_ready(qspi_dev)) {
		shell_error(sh, "NRF-06 FAIL: mx25r64 driver did not init.");
		shell_print(sh, "The driver verifies JEDEC ID C2 28 17 at boot — a ready");
		shell_print(sh, "device IS the ID check. Not ready -> wiring/rail/ID problem.");
		return -ENODEV;
	}
	uint8_t buf[16];
	int err = flash_read(qspi_dev, 0, buf, sizeof(buf));
	shell_print(sh, "NRF-06 PASS: MX25R6435F on 3V3_NRF answered (JEDEC C2 28 17");
	shell_print(sh, "verified by driver). First 16 bytes @0x0: err=%d", err);
	shell_hexdump(sh, buf, sizeof(buf));
	return 0;
}

static int cmd_qspi_test(const struct shell *sh, size_t argc, char **argv)
{
	static uint8_t wr[256], rd[256];
	for (int i = 0; i < 256; i++) wr[i] = (uint8_t)(i ^ 0xA5);
	int err = flash_erase(qspi_dev, QSPI_TEST_OFF, 4096);
	err |= flash_write(qspi_dev, QSPI_TEST_OFF, wr, sizeof(wr));
	err |= flash_read(qspi_dev, QSPI_TEST_OFF, rd, sizeof(rd));
	bool match = (err == 0) && (memcmp(wr, rd, sizeof(rd)) == 0);
	shell_print(sh, "NRF-07 erase/write/verify @0x%X: %s (err=%d)",
		    QSPI_TEST_OFF, match ? "PASS" : "FAIL", err);
	return match ? 0 : -EIO;
}

static int cmd_qspi_dpd(const struct shell *sh, size_t argc, char **argv)
{
	bool on = (argc > 1 && strcmp(argv[1], "on") == 0);
	int err = pm_device_action_run(qspi_dev, on ? PM_DEVICE_ACTION_SUSPEND
						    : PM_DEVICE_ACTION_RESUME);
	shell_print(sh, "IMEAS-06: MX25R64 %s (deep-power-down %s) err=%d",
		    on ? "suspended" : "resumed", on ? "entered" : "left", err);
	shell_print(sh, "Watch the J2 meter: awake standby ~5-10 uA vs DPD <1 uA.");
	return err;
}

/* -------------------- dvt usb on  (NRF-08) ------------------------ */
static int cmd_usb(const struct shell *sh, size_t argc, char **argv)
{
#if defined(CONFIG_USB_DEVICE_STACK)
	shell_print(sh, "NRF-08: slide SW1 to APP first (routes J1 to the nRF).");
	int err = usb_enable(NULL);
	shell_print(sh, "usb_enable() = %d. Host should enumerate a new CDC-ACM", err);
	shell_print(sh, "port (Nordic VID 0x2FE3/Zephyr default). This proves the");
	shell_print(sh, "FSUSB42 APP path + R28/C48 VBUS sense + module USB pins.");
	shell_print(sh, "Slide SW1 back to DEBUG when done (console lives on the probe).");
	return err;
#else
	shell_error(sh, "USB stack not built in");
	return -ENOTSUP;
#endif
}

/* ------------- dvt ble adv [0|3] / stop  (RF-01..07) -------------- */
#if defined(CONFIG_BT)
static bool bt_ready;
static int set_tx_power(const struct shell *sh, int8_t dbm)
{
	struct bt_hci_cp_vs_write_tx_power_level *cp;
	struct net_buf *buf = bt_hci_cmd_create(BT_HCI_OP_VS_WRITE_TX_POWER_LEVEL,
						sizeof(*cp));
	if (!buf) return -ENOBUFS;
	cp = net_buf_add(buf, sizeof(*cp));
	cp->handle_type = BT_HCI_VS_LL_HANDLE_TYPE_ADV;
	cp->handle = 0;
	cp->tx_power_level = dbm;
	int err = bt_hci_cmd_send_sync(BT_HCI_OP_VS_WRITE_TX_POWER_LEVEL, buf, NULL);
	shell_print(sh, "TX power -> %+d dBm (%s)", dbm, err ? "VS cmd failed, staying at default 0 dBm" : "ok");
	return err;
}

static int cmd_ble_adv(const struct shell *sh, size_t argc, char **argv)
{
	int err;
	if (!bt_ready) {
		err = bt_enable(NULL);
		if (err) {
			shell_error(sh, "RF-01 bt_enable failed (%d).", err);
			shell_print(sh, "Most likely the NETWORK CORE is blank — flash the");
			shell_print(sh, "sysbuild ipc_radio image first (Firmware Guide §4).");
			return err;
		}
		bt_ready = true;
	}
	if (argc > 1) set_tx_power(sh, (int8_t)atoi(argv[1]));   /* RF-05: 0 or 3 */
	static const struct bt_data ad[] = {
		BT_DATA_BYTES(BT_DATA_FLAGS, BT_LE_AD_GENERAL | BT_LE_AD_NO_BREDR),
		BT_DATA(BT_DATA_NAME_COMPLETE, CONFIG_BT_DEVICE_NAME,
			sizeof(CONFIG_BT_DEVICE_NAME) - 1),
	};
	err = bt_le_adv_start(BT_LE_ADV_CONN_FAST_2, ad, ARRAY_SIZE(ad), NULL, 0);
	if (err == -EALREADY) err = 0;
	shell_print(sh, "RF-01: advertising as '%s' %s", CONFIG_BT_DEVICE_NAME,
		    err ? "FAILED" : "— find it in nRF Connect (RF-02..04)");
	return err;
}

static int cmd_ble_stop(const struct shell *sh, size_t argc, char **argv)
{
	bt_le_adv_stop();
	shell_print(sh, "Advertising stopped.");
	return 0;
}
#endif /* CONFIG_BT */

/* ------------- dvt cpu / sleep ...  (IMEAS-03/04/05) -------------- */
static int cmd_cpu(const struct shell *sh, size_t argc, char **argv)
{
	shell_print(sh, "IMEAS-03: 30 s CPU busy-loop starts in 3 s — read J2 meter.");
	k_sleep(K_MSEC(3000));
	volatile uint32_t x = 1;
	int64_t end = k_uptime_get() + 30000;
	while (k_uptime_get() < end) { x = x * 1664525u + 1013904223u; }
	shell_print(sh, "Done (x=%u).", x);
	return 0;
}

static void quiesce(const struct shell *sh)
{
#if defined(CONFIG_BT)
	if (bt_ready) { bt_le_adv_stop(); }
#endif
	if (device_is_ready(qspi_dev))
		pm_device_action_run(qspi_dev, PM_DEVICE_ACTION_SUSPEND);
	shell_print(sh, "QSPI flash -> DPD. Detach any debug session (pyocd/gdb).");
	shell_print(sh, "UART console suspends NOW — RTT stays alive. Reset (SW4) to recover.");
	k_sleep(K_MSEC(100));
	pm_device_action_run(uart0_dev, PM_DEVICE_ACTION_SUSPEND);
}

static int cmd_sleep_idle(const struct shell *sh, size_t argc, char **argv)
{
	shell_print(sh, "IMEAS-04 System ON idle in 5 s. J2 meter on uA range.");
	k_sleep(K_MSEC(5000));
	quiesce(sh);
	while (1) { k_sleep(K_FOREVER); }
	return 0;
}

static int cmd_sleep_off(const struct shell *sh, size_t argc, char **argv)
{
	shell_print(sh, "IMEAS-05 System OFF in 5 s. Wake = reset (SW4). uA range.");
	k_sleep(K_MSEC(5000));
	quiesce(sh);
	sys_poweroff();
	return 0;   /* not reached */
}

/* -------------------- dvt demo  (SYS-01/03) ----------------------- */
static int cmd_demo(const struct shell *sh, size_t argc, char **argv)
{
	shell_print(sh, "SYS-01 soak: SHT4x poll every 2 s + BLE adv (if net core");
	shell_print(sh, "present). Runs until reset. Log start time in the tracker.");
#if defined(CONFIG_BT)
	cmd_ble_adv(sh, 1, argv);
#endif
	uint32_t n = 0;
	while (1) {
		uint8_t c = 0xFD, rx[6];
		int err = i2c_write(i2c_dev, &c, 1, 0x44);
		k_sleep(K_MSEC(12));
		err |= i2c_read(i2c_dev, rx, 6, 0x44);
		if (!err) {
			double t  = -45.0 + 175.0 * ((rx[0] << 8 | rx[1]) / 65535.0);
			double rh = -6.0  + 125.0 * ((rx[3] << 8 | rx[4]) / 65535.0);
			shell_print(sh, "[%6u] T=%.2fC RH=%.1f%% up=%llds",
				    n, t, rh, k_uptime_get() / 1000);
		} else {
			shell_print(sh, "[%6u] SHT4x err=%d up=%llds",
				    n, err, k_uptime_get() / 1000);
		}
		n++;
		k_sleep(K_MSEC(2000));
	}
	return 0;
}

/* --------------------------- shell tree --------------------------- */
SHELL_STATIC_SUBCMD_SET_CREATE(sub_gpio,
	SHELL_CMD(walk, NULL, "walking output [all]        (GPIO-01)", cmd_gpio_walk),
	SHELL_CMD(in,   NULL, "inputs w/ pull-ups, 20 s    (GPIO-02)", cmd_gpio_in),
	SHELL_CMD(pattern, NULL, "adjacent-bridge auto test (GPIO-03)", cmd_gpio_pattern),
	SHELL_SUBCMD_SET_END);
SHELL_STATIC_SUBCMD_SET_CREATE(sub_i2c,
	SHELL_CMD(scan,  NULL, "bus scan [fast]         (I2C-02/04)", cmd_i2c_scan),
	SHELL_CMD(sht4x, NULL, "read SHT4x [fast]       (I2C-03/04)", cmd_i2c_sht4x),
	SHELL_SUBCMD_SET_END);
SHELL_STATIC_SUBCMD_SET_CREATE(sub_qspi,
	SHELL_CMD(id,   NULL, "flash present / JEDEC     (NRF-06)", cmd_qspi_id),
	SHELL_CMD(test, NULL, "erase/write/verify        (NRF-07)", cmd_qspi_test),
	SHELL_CMD(dpd,  NULL, "on|off deep-power-down    (IMEAS-06)", cmd_qspi_dpd),
	SHELL_SUBCMD_SET_END);
SHELL_STATIC_SUBCMD_SET_CREATE(sub_sleep,
	SHELL_CMD(idle, NULL, "System ON idle            (IMEAS-04)", cmd_sleep_idle),
	SHELL_CMD(off,  NULL, "System OFF                (IMEAS-05)", cmd_sleep_off),
	SHELL_SUBCMD_SET_END);
#if defined(CONFIG_BT)
SHELL_STATIC_SUBCMD_SET_CREATE(sub_ble,
	SHELL_CMD(adv,  NULL, "advertise [0|3 dBm]     (RF-01/05)", cmd_ble_adv),
	SHELL_CMD(stop, NULL, "stop advertising", cmd_ble_stop),
	SHELL_SUBCMD_SET_END);
#endif
SHELL_STATIC_SUBCMD_SET_CREATE(sub_dvt,
	SHELL_CMD(info, NULL, "board info / S-N / reset  (NRF-03)", cmd_info),
	SHELL_CMD(clk,  NULL, "LFCLK status; 'clk cal'   (NRF-04/05)", cmd_clk),
	SHELL_CMD(gpio, &sub_gpio, "GPIO tests", NULL),
	SHELL_CMD(adc,  NULL, "dump AIN0..7 mV           (GPIO-04)", cmd_adc),
	SHELL_CMD(i2c,  &sub_i2c, "I2C / Qwiic tests", NULL),
	SHELL_CMD(qspi, &sub_qspi, "QSPI flash tests", NULL),
	SHELL_CMD(usb,  NULL, "enable nRF native USB     (NRF-08)", cmd_usb),
#if defined(CONFIG_BT)
	SHELL_CMD(ble,  &sub_ble, "BLE tests", NULL),
#endif
	SHELL_CMD(cpu,  NULL, "30 s busy-loop            (IMEAS-03)", cmd_cpu),
	SHELL_CMD(sleep, &sub_sleep, "low-power entry", NULL),
	SHELL_CMD(demo, NULL, "SHT4x + BLE soak loop     (SYS-01/03)", cmd_demo),
	SHELL_SUBCMD_SET_END);
SHELL_CMD_REGISTER(dvt, &sub_dvt, "nRF5340 board DVT commands", NULL);

int main(void)
{
	printk("\n=== %s v%s | %s ===\n", FW_NAME, FW_VER, BOARD_REV);
	printk("Console: RP2040 probe CDC @115200 (uart0 P0.20/P0.22) + RTT.\n");
	printk("Type `dvt` for the test menu. Test IDs match the DVT plan.\n");
	return 0;
}
