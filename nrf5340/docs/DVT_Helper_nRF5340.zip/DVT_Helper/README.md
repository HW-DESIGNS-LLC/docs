# DVT_Helper — nRF5340 BLE Dev Board (Rev B) bring-up firmware

Shell-driven self-test firmware for the HW Designs nRF5340 board
(MDBT53-1M + RP2040 CMSIS-DAP probe). Every command is tagged with its
DVT plan test ID. Full instructions live in `DVT_Firmware_Guide.docx`;
this file is the 60-second version.

## Build (NCS v2.9+ / v3.x)

```
west build -b nrf5340dk/nrf5340/cpuapp --sysbuild
```

The board is DK-pin-compatible (uart0, i2c1, QSPI MX25R64). The one
deviation — LFXO internal 6 pF load caps — is already in `prj.conf`.
**Smoke-build once before DVT day**; this app targets NCS 2.9/3.x APIs.

## Flash — over the onboard RP2040 probe (CMSIS-DAP)

The nRF Connect VS Code **Flash/Debug buttons will not see this probe**
(they call nrfutil/J-Link). Use the terminal:

```
# one-time on a virgin module (APPROTECT ships enabled):
probe-rs erase --chip nRF5340_xxAA --allow-erase-all

# net core (BLE controller), then app core:
probe-rs download --chip nRF5340_xxAA --binary-format hex build/merged_CPUNET.hex
probe-rs download --chip nRF5340_xxAA --binary-format hex build/merged.hex
probe-rs reset    --chip nRF5340_xxAA
```

pyOCD (`west flash --runner pyocd`) and OpenOCD also work for the app
core; probe-rs is the smoothest path for the net core over CMSIS-DAP.
Fallback: a J-Link on the TC2030 pads (J4) flashes both cores with the
stock Nordic tools. Debug: Cortex-Debug extension + pyocd/probe-rs.

## Use

Open the probe's CDC serial port at 115200 (it enumerates next to the
CMSIS-DAP interface) or an RTT viewer, then:

```
dvt info          # NRF-03  board S/N (FICR), reset reason, LFCLK
dvt clk cal       # NRF-05  LFXO ppm vs HFXO (catches wrong load caps)
dvt gpio walk     # GPIO-01 walking output on 23 header GPIOs ([all]=27)
dvt gpio in       # GPIO-02 pull-up input table
dvt gpio pattern  # GPIO-03 adjacent-bridge auto test
dvt adc           # GPIO-04 AIN0..7 dump
dvt i2c scan      # I2C-02  Qwiic scan   (add `fast` = 400 kHz, I2C-04)
dvt i2c sht4x     # I2C-03  SHT4x T/RH + CRC
dvt qspi id|test  # NRF-06/07  MX25R64 present / erase-write-verify
dvt qspi dpd on   # IMEAS-06  flash deep-power-down (watch J2 meter)
dvt usb           # NRF-08  nRF native USB (SW1 -> APP first)
dvt ble adv [0|3] # RF-01/05  advertise at 0 or +3 dBm
dvt cpu           # IMEAS-03  30 s busy-loop
dvt sleep idle    # IMEAS-04  System ON idle (console dies; RTT lives)
dvt sleep off     # IMEAS-05  System OFF (wake = SW4)
dvt demo          # SYS-01/03 SHT4x + BLE soak loop
```

RP2040 side: stock `debugprobe_on_pico.uf2` (release ≥ 2.2) — no custom
firmware. SW1=DEBUG, BOOTSEL via SW2+SW3, drag the UF2 onto RPI-RP2.
